#!/bin/bash
while :
do
  source venv/bin/activate
  python main.py
done;

