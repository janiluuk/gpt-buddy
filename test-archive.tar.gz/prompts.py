assistant_image_prompt = """
You are a voice assistant that can display images on a display. Given the following input, display generate an image that we
can show the user:
"""

scheduled_image_prompt = """
Create a scene out of the topics and descriptions we've talked about recently.
"""
